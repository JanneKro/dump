extends Node3D

@export var treasure_packed_scene : PackedScene
var treasure = null
var anim_position := 0.0

func _ready():
	if treasure_packed_scene == null:
		return
	treasure = treasure_packed_scene.instantiate()
	%TreasurePosition.add_child(treasure)


func _process(delta):
	anim_position += delta
	%TreasurePosition.position.y += sin(anim_position * 5) * 0.01
	%TreasurePosition.rotation.y += delta * 1
