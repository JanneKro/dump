extends Node2D

@onready var circle := CircleShape2D.new()


func _draw():
	draw_circle(Vector2(0,0), 50.0, "White")

