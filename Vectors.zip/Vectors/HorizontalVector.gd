extends Node2D

var radius = 50.0
var hComponent := Vector2(0,0)

func _process(delta):
	hComponent[0] = Input.get_axis("move_left", "move_right")
	queue_redraw()
	
func _draw():
	draw_line(Vector2(0,0), hComponent * radius, "Blue", 8)
