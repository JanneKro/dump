extends Node2D

var radius = 50
var sum := Vector2(0, 0)

func _process(delta):
	sum = %HorizontalVector.hComponent + %VerticalVector.vComponent
	queue_redraw()

func _draw():
	draw_line(Vector2(0,0), sum * radius, "Purple", 3)

