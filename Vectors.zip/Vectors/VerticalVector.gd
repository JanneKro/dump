extends Node2D

var radius = 50
var vComponent := Vector2(0, 0)

func _process(delta):
	vComponent[1] = Input.get_axis("move_up", "move_down")
	queue_redraw()

func _draw():
	draw_line(Vector2(0,0), vComponent * radius, "Red", 8)
