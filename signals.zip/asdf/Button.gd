extends Button

signal five_presses


var counter = 0


func _on_pressed():
	counter += 1
	if counter >= 5:
		emit_signal("five_presses")
	pass # Replace with function body.
