extends Label

func on_five_presses():
	self.text = "The button has been pressed five times!"

func _ready():
	%Button.five_presses.connect(self.on_five_presses, CONNECT_ONE_SHOT )

func _on_timer_timeout():
	self.text = ""
